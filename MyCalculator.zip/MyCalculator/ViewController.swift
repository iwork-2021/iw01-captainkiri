//
//  ViewController.swift
//  MyCalculator
//
//  Created by 李正浩 on 2021/10/9.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var DisplayLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.DisplayLabel.text! = ""
    }
    
    var digitOnDisplay: String{
        get{
            return self.DisplayLabel.text!
        }
        
        set {
            self.DisplayLabel.text! = newValue
        }
    }

    var inTypingMode = false
    var thereIsADot = false
    
    @IBAction func NumberTouched(_ sender: UIButton) {
        //print("Number \(sender.currentTitle!) touched")
        
        if sender.currentTitle == "."{
            thereIsADot = true
            inTypingMode = true
        }
            
/*        if thereIsADot{
            if sender.currentTitle == "."{
                digitOnDisplay = digitOnDisplay + sender.currentTitle!
            } else {
                digitOnDisplay = digitOnDisplay + sender.currentTitle!
            }
        } else {
            if inTypingMode{
                digitOnDisplay = digitOnDisplay + sender.currentTitle!
            } else {
                digitOnDisplay = sender.currentTitle!
                inTypingMode = true
            }
        }
*/
        if inTypingMode{
            digitOnDisplay = digitOnDisplay + sender.currentTitle!
        } else {
            digitOnDisplay = sender.currentTitle!
            inTypingMode = true
        }
    }
    
    let calculator = Calculator()
    
    @IBAction func OperatorTouched(_ sender: UIButton) {
//        print("Operator \(sender.currentTitle!) touched")
        
        if let op = sender.currentTitle {
            if let result = calculator.PerformOperation(operation: op, operand: Double(digitOnDisplay)!){
                digitOnDisplay = String(result)
            }
            
            inTypingMode = false
        }
    }
    
    //回退函数
    @IBAction func returntomain(segue: UIStoryboardSegue){
        
    }
    
    
}

