//
//  Calculator.swift
//  MyCalculator
//
//  Created by 李正浩 on 2021/10/9.
//

import UIKit

class Calculator: NSObject {
    enum Operation{
        case UnaryOp((Double)->Double)
        case BinaryOp((Double,Double)->Double)
        case EqualOp
        case Constant(Double)
    }
    
    var operations = [
        "+": Operation.BinaryOp{
            (op1,op2) in
            return op1 + op2
        },
        
        "-": Operation.BinaryOp{
            (op1,op2) in
            return op1 - op2
        },
        
        "x": Operation.BinaryOp{
            (op1,op2) in
            return op1 * op2
        },
        
        "/": Operation.BinaryOp{
            (op1,op2) in
            return op1 / op2
        },
        
        ".": Operation.BinaryOp{
            (op1,op2) in
            var a = 10.0
            while((op2/a)>=1) {a = a*10}
            var ans = op1 + op2/a
            return ans
        },
        
        "=": Operation.EqualOp,
        
        "%": Operation.UnaryOp{
            op in
            return op/100.0
        },
        
        "+/-": Operation.UnaryOp{
            op in
            return -op
        },
        
        "clear": Operation.UnaryOp{
            _ in
            return 0
        },
        
        "pi": Operation.Constant(3.14),
        
        "Rand": Operation.UnaryOp{
            _ in
            return drand48()
        },
        
        "x^2": Operation.UnaryOp{
            op in
            return op * op
        },
    
        "x^3": Operation.UnaryOp{
            op in
            return op * op * op
        },
        
        "x^y": Operation.BinaryOp{
            (op1,op2) in
            return pow(op1, op2)
        },
        
        "y^x": Operation.BinaryOp{
            (op1,op2) in
            return pow(op2, op1)
        },
        
        "e^x": Operation.UnaryOp{
            op in
            return pow(2.718, op)
        },
    
        "1/x": Operation.UnaryOp{
            op in
            return 1 / op
        },
    
        "x^1/2": Operation.UnaryOp{
            op in
            return pow(op, 0.5)
        },
    
        "x^1/3": Operation.UnaryOp{
            op in
            return pow(op, 1/3)
        },
        
        "x^1/y": Operation.BinaryOp{
            (op1, op2) in
            return pow(op1, 1/op2)
        },
        
        "ln": Operation.UnaryOp{
            op in
            return log(op)
        },
        
        "log10": Operation.UnaryOp{
            op in
            return log10(op)
        },
        
        "x!": Operation.UnaryOp{
            op in
            var a = 1.0
            var b = op
            while b>1{
                a = a * b
                b = b - 1
            }
            return a
        },
        
        "sin": Operation.UnaryOp{
            op in
            return sin(op)
        },
        
        "cos": Operation.UnaryOp{
            op in
            return cos(op)
        },
        
        "tan": Operation.UnaryOp{
            op in
            return tan(op)
        },
        
        "e": Operation.Constant(2.71),
        
        "EE": Operation.BinaryOp{
            (op1, op2) in
            return op1 * pow(10, op2)
        },
        
        "sinh": Operation.UnaryOp{
            op in
            return sinh(op)
        },
        
        "cosh": Operation.UnaryOp{
            op in
            return cosh(op)
        },
        
        "tanh": Operation.UnaryOp{
            op in
            return tanh(op)
        },
        
        "10^x": Operation.UnaryOp{
            op in
            return pow(10, op)
        },
        
        "2^x": Operation.UnaryOp{
            op in
            return pow(2, op)
        },
        
        "log2": Operation.UnaryOp{
            op in
            return log2(op)
        },
        
        "logy": Operation.BinaryOp{
            (op1, op2) in
            return log(op2)/log(op1)
        },
        
        "arcsin": Operation.UnaryOp{
            op in
            return asin(op)
        },
        
        "arccos": Operation.UnaryOp{
            op in
            return acos(op)
        },
        
        "arctan": Operation.UnaryOp{
            op in
            return atan(op)
        },
        
        "arcsinh": Operation.UnaryOp{
            op in
            return asinh(op)
        },
        
        "arccosh": Operation.UnaryOp{
            op in
            return acosh(op)
        },
        
        "arctanh": Operation.UnaryOp{
            op in
            return atanh(op)
        },
    
    ]

    
    struct InterMediate{
        var firstOp: Double
        var waitingOperation: (Double,Double) -> Double
    }
    
    var pendingOp: InterMediate? = nil
    
    func PerformOperation(operation: String, operand: Double) -> Double?{
        if let op = operations[operation]{
            switch op{
            case .BinaryOp(let function):
                pendingOp = InterMediate(firstOp: operand, waitingOperation: function)
                return nil
            case .Constant(let value):
                return value
            case .EqualOp:
                return pendingOp!.waitingOperation(pendingOp!.firstOp,operand)
            case .UnaryOp(let function):
                return function(operand)
            }
        }
        return nil
    }
}
